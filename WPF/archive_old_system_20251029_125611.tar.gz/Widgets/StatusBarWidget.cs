using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SuperTUI.Core;
using SuperTUI.Core.Components;
using SuperTUI.Core.Infrastructure;
using SuperTUI.Core.Services;
using SuperTUI.Infrastructure;

namespace SuperTUI.Widgets
{
    /// <summary>
    /// Persistent status bar showing: [Project: Name] [Context: Views] [⏱️ Time]
    /// </summary>
    public class StatusBarWidget : WidgetBase, IThemeable
    {
        private readonly ILogger logger;
        private readonly IThemeManager themeManager;
        private readonly IProjectContextManager projectContext;
        private readonly ITimeTrackingService timeTracking;

        private TextBlock projectLabel;
        private TextBlock contextLabel;
        private TextBlock timeLabel;
        private Border container;

        public StatusBarWidget(
            ILogger logger,
            IThemeManager themeManager,
            IProjectContextManager projectContext,
            ITimeTrackingService timeTracking)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.themeManager = themeManager ?? throw new ArgumentNullException(nameof(themeManager));
            this.projectContext = projectContext ?? throw new ArgumentNullException(nameof(projectContext));
            this.timeTracking = timeTracking ?? throw new ArgumentNullException(nameof(timeTracking));

            WidgetName = "StatusBar";
            BuildUI();
        }

        public StatusBarWidget()
            : this(
                Logger.Instance,
                ThemeManager.Instance,
                ProjectContextManager.Instance,
                TimeTrackingService.Instance)
        {
        }

        private void BuildUI()
        {
            var grid = new Grid
            {
                Height = 30
            };

            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(200) });

            // Project context
            projectLabel = new TextBlock
            {
                Text = "[Project: None]",
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(10, 0, 0, 0),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 12
            };
            Grid.SetColumn(projectLabel, 0);
            grid.Children.Add(projectLabel);

            // View context
            contextLabel = new TextBlock
            {
                Text = "[Context: Workspace]",
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                FontFamily = new FontFamily("Consolas"),
                FontSize = 12
            };
            Grid.SetColumn(contextLabel, 1);
            grid.Children.Add(contextLabel);

            // Time tracker
            timeLabel = new TextBlock
            {
                Text = "[⏱️ 0h 0m]",
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 0, 10, 0),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 12
            };
            Grid.SetColumn(timeLabel, 2);
            grid.Children.Add(timeLabel);

            container = new Border
            {
                Child = grid,
                BorderThickness = new Thickness(0, 1, 0, 0),
                Padding = new Thickness(0)
            };

            Content = container;
            ApplyTheme();
        }

        public override void Initialize()
        {
            // Subscribe to context changes
            projectContext.ProjectContextChanged += OnProjectContextChanged;

            // Update initial state
            UpdateProjectLabel();
            UpdateTimeLabel();

            // Start timer for time updates
            var timer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(10)
            };
            timer.Tick += (s, e) => UpdateTimeLabel();
            timer.Start();

            logger.Log(LogLevel.Info, WidgetName, "StatusBar initialized");
        }

        private void OnProjectContextChanged(object? sender, ProjectContextChangedEventArgs e)
        {
            UpdateProjectLabel();
            UpdateTimeLabel();
        }

        private void UpdateProjectLabel()
        {
            Application.Current?.Dispatcher.Invoke(() =>
            {
                if (projectContext.CurrentProject != null)
                {
                    projectLabel.Text = $"[Project: {projectContext.CurrentProject.Name}]";
                }
                else
                {
                    projectLabel.Text = "[Project: All]";
                }
            });
        }

        public void SetContext(string contextInfo)
        {
            Application.Current?.Dispatcher.Invoke(() =>
            {
                contextLabel.Text = $"[Context: {contextInfo}]";
            });
        }

        private void UpdateTimeLabel()
        {
            Application.Current?.Dispatcher.Invoke(() =>
            {
                // Get this week's entries for current project
                var allEntries = timeTracking.GetAllEntries();
                var thisWeek = allEntries.FindAll(e =>
                    e.WeekEnding >= DateTime.Today.AddDays(-7) &&
                    (projectContext.CurrentProject == null || e.ProjectId.ToString() == projectContext.CurrentProject.Id.ToString()));

                var totalMinutes = thisWeek.Sum(e => e.Hours * 60);
                var hours = (int)(totalMinutes / 60);
                var minutes = (int)(totalMinutes % 60);

                timeLabel.Text = $"[⏱️ {hours}h {minutes}m]";
            });
        }

        public void ApplyTheme()
        {
            var theme = themeManager.CurrentTheme;
            if (theme == null) return;

            var bg = theme.GetColor("background");
            var fg = theme.GetColor("foreground");
            var border = theme.GetColor("border");

            container.Background = new SolidColorBrush(bg);
            container.BorderBrush = new SolidColorBrush(border);

            projectLabel.Foreground = new SolidColorBrush(fg);
            contextLabel.Foreground = new SolidColorBrush(fg);
            timeLabel.Foreground = new SolidColorBrush(fg);
        }

        protected override void OnDispose()
        {
            projectContext.ProjectContextChanged -= OnProjectContextChanged;
            base.OnDispose();
        }
    }
}
